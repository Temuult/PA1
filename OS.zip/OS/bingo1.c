#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main () {
   //char command[50];

   //strcpy( command, "echo 1001 > /proc/dogdoor" );
   system("echo '2 free 2812' > /proc/dogdoor");

   return 0;
} 
