#include<stdio.h>
#include <pwd.h>
struct passwd *pw;
int main(){	
	int a;
	pw=getpwnam("temuul");
	a=pw->pw_uid;	
	printf("/n %d",a);
	return 0;
}
